# Study II 原录音配置 / Original recording configurations

本包保存已经执行的1,440个数据/模型配置。无需原仓库路径即可校验并导出单个配置。仅需Python标准库，不用GPU。

在解压后的本目录执行：

```shell
python tools/recipe_bundle.py verify --bundle data
python tools/recipe_bundle.py export --bundle data --unit-id e890d24810c9f91a11f1fcf8b78d5904d497b78ed0bda3b75b4642b335fe5fc5 --out example
```

示例只是原计划首项，不是推荐配置。全部原单位在data/units.json；720个fit、90个val、90个test清单按原顺序去重引用。导出fit.csv/val.csv/test.csv携带原录音相对路径、SHA、人物、文本、情绪、强度和来源性别元数据；unit.json保留原配置及种子。val是早停验证，test是最终测试。每次选择不存在或为空的输出目录。

本包不含音频、缓存、权重或预测数组。verify核对当前包和原计划身份，不重新训练，也不复算科学结果；真实音频尚需使用者逐文件哈希核对。历史验收记录及其原电脑路径按原字节保存，不代表在当前机器重新执行了该验收。

人数12/48和每人文本覆盖同时变化；288/576是拟合录音条数预算。prompt_seen/new指文本，最终测试人物均未参与拟合。不同划分不得合并后仍声称测试未见人。这些配置未证明通用最优或SD/SI差距消除。

This metadata-only package losslessly reconstructs all 1,440 executed Study II units from 720 fit, 90 validation, and 90 test lists. The example is the first original unit, not an outcome-selected recommendation. Python's standard library is sufficient. No audio, caches, weights, or prediction arrays are distributed. Package validation is not retraining, audio verification, or scientific result recomputation. Original historical receipts are preserved without rebinding their paths. Speaker count and per-speaker prompt coverage vary jointly; no optimal dataset or elimination of SD/SI gaps is established.

The delivery manifest records this packaging operation after the original study's results were known. It is not a new preregistration. The original plan lock is preserved inside data/originals. The outer ZIP SHA must be shared separately when transferring the package.
